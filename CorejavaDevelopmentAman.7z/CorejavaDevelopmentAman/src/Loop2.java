
public class Loop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=2;
		while(i<=20)
			{
			System.out.println(i);
			i+=2;
	}

}}
