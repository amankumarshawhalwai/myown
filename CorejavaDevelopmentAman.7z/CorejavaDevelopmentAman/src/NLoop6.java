
public class NLoop6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
	      for(i=1;i<=5;i++)
	      {
	        System.out.println();
	        for(j=1;j<=i;j++)
	          //System.out.print(i+" ");
	        	System.out.print("*");
	      }
	      for(i=4;i>=1;i--)
	       {
	         System.out.println();
	         for(j=i;j>=1;j--)
	           //System.out.print(i+" ");
	        	 System.out.print("*");
	        }
	}

}
