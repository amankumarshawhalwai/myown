import java.util.Scanner;
public class ScannerDemo1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sno,sub1,sub2;
		String sname;
		System.out.println("Enter student no: ");
		sno=sc.nextInt();
		System.out.println("Enter Student name:");
		sname=sc.next();
		System.out.println("Enter sub1 marks:");
	    sub1=sc.nextInt();
		System.out.println("Enter sub1 marks:");
		sub2=sc.nextInt();
		
		System.out.println("Student number is:"+sno);
		System.out.println("Student Name:"+sname);
		System.out.println("Subject marks 1:"+sub1);
		System.out.println();
		
		

	}

}
