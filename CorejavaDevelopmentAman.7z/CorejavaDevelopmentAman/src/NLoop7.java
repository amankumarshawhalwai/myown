
public class NLoop7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		for(i=1;i<=20;)
		{
			for(j=i;j<=20;j++)
				System.out.print(j+" ");
			break;
		}
	}

}
