
public class Myname {

	public static void main(String[] args) {
		
       System.out.println("Aman");
    
	}

}
