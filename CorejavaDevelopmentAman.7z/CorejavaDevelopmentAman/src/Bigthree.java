
public class Bigthree {

	public static void main(String[] args) {
		int a=10,b=20,c=50;
		if(a>b && a>c)
			System.out.println("a is big");
		else if(b>a && b>c)
			System.out.println("b is big");
		else
			System.out.println("c is big");
	}

}
