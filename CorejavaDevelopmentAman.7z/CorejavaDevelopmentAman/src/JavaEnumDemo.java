
public class JavaEnumDemo {
 public enum Days{
	 SUNDAY,MONDAY,TUESDAY,THURSDAY,FRIDAY,SATURDAY
 }
	public static void main(String[] args) {
		
System.out.println(Days.SATURDAY);

Days myDay=Days.THURSDAY;
System.out.println("This is my day:"+myDay);
	}

}
