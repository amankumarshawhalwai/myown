package com.capg.test;//original package


//this program illustrates the inheritance of functionalities not from within the same package
import com.capg.corejava.oops.Calculation;//package from where functionalities are getting imported
public class Mycheck extends Calculation{

	public static void main(String[] args) {
		Mycheck my=new Mycheck();
		my.addition();
		my.sub();
	}

}
