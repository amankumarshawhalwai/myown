package com.capg.corejava.arrays;

public class ArraysDemo7Multi {

	public static void main(String[] args) {
		int arr[][]=new int[5][5];
		int i,j;
		for(i=0;i<5;i++)
		{
			for(j=0;j<5;j++)
			{
				if(i==j)
					arr[i][j]=1;
				else
					arr[i][j]=0;
			}
				
		
		for(i=0;i<5;i++)
		{
			System.out.println();
			for(j=0;j<5;j++)
				System.out.print(" " +arr[i][j]);
		}

	}

}}
