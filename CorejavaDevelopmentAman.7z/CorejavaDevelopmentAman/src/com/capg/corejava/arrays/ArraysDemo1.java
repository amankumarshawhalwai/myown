package com.capg.corejava.arrays;

public class ArraysDemo1 {

	public static void main(String[] args) {
//we didn't initialize here	
		int ar[]= {10,20,30};
		System.out.println(ar[0]);
		System.out.println(ar[1]);
		System.out.println(ar[2]);

	}

}
