package com.capg.corejava.arrays;

public class ArraysDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[]=new int[5];
		
		ar[0]=10;
		ar[1]=20;
		ar[2]=30;
		ar[3]=40;
		ar[4]=50;
		for(int i=0;i<ar.length;i++)
			System.out.println(ar[i]);
		
		for(int k:ar)//advanced loop it is automatically done internally by the system
			//& same data type is only accepted. This does the same function as a normal loop
			System.out.println(k);
	}

}
