package com.capg.corejava.oops;
//illustration of Inheritance
public class Myclass extends Calculation{

	public static void main(String[] args) {
		
		Myclass my = new Myclass();
		my.addition();
		my.sub();
		my.multi();
		my.div();
	}

}
