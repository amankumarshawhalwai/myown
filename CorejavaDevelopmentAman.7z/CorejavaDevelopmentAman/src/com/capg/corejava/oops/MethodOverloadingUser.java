package com.capg.corejava.oops;

public class MethodOverloadingUser {
	public void user()
	{
		System.out.println("user");
	}
	public void user(String username,String password)
	{
		System.out.println("Username is:"+username);
		System.out.println("Password is:"+password);
	}
	public void user(int mobile,String password)
	{
		System.out.println("Mobile is:"+mobile);
		System.out.println("Password is:"+password);
	}
	public static void main(String[] args) {
		MethodOverloadingUser myuser = new MethodOverloadingUser();
		myuser.user();
		myuser.user("aman","aman123");
		myuser.user(123456789,"aman123");

	}

}
