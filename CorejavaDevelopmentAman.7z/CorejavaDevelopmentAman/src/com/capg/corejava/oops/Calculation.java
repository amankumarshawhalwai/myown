package com.capg.corejava.oops;

public class Calculation {//class
	int a=100,b=20,c;// attributes
	public void addition()//method 1
	{
		c=a+b;
		System.out.println("Addition: "+c);
	}
	public void sub()//method 2
	{
		c=a-b;
		System.out.println("Sub: "+c);
	}
	public void multi()//method 3
	{
		c=a*b;
		System.out.println("Multiplication: "+c);
	}
	public void div()//method 4
	{
		c=a/b;
		System.out.println("Division: "+c);
	}
	public static void main(String[] args) {
		Calculation cal = new Calculation();//object creation
		//cal is a reference to call the calculation object
		cal.addition();
		cal.sub();
		cal.multi();
		cal.div();

	}//main class closure

}//class closure

//illustration of binding of attributes and methods together inside 
// a class and objects which is nothing but encapsulation
