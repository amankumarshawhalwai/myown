package com.capg.corejava.oops;

public class MethodsFlow {
	
	public void myName() 
	{
		System.out.println("No Parameters with No Return Values");
	}
	public void myCountry(String country)
	{
		System.out.println("My Country name is:"+country);
		System.out.println("Parameters with No return values");
	}
	public int mul(int a,int b)
	{
		int c=a*b;
		return c;
	}
	public int add()
	{
		int a=2,b=2;
		return (a+b);//no parameters with return values
	}

	public static void main(String[] args) {
		MethodsFlow flow=new MethodsFlow();
		flow.myName();
		flow.myCountry("India");
		int t=flow.mul(2,2);
		System.out.println("Multiplication is:"+t);
		int k= flow.add();
		System.out.println("Addition is:"+k);
		

	}

}
