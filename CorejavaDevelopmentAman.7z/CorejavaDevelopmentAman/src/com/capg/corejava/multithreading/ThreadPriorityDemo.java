package com.capg.corejava.multithreading;


public class ThreadPriorityDemo  extends Thread{
	
	public void run()
	{
		System.out.println("Running thread name  :"+Thread.currentThread().getName());
		System.out.println("Running thread Priority is "+Thread.currentThread().getPriority());
	}
	

	public static void main(String[] args) {
		
		ThreadPriorityDemo t1=new ThreadPriorityDemo();
		ThreadPriorityDemo t2=new ThreadPriorityDemo();
		
		//t1.start();
		
	//t1.setPriority(7);
		//t2.setPriority(MIN_PRIORITY);
//				
//		t1.start();
     	t2.start();
//		
//		
	System.out.println("Thread Current Priority :"+Thread.currentThread().getPriority());

	}

}
