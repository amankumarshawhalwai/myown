package com.capg.corejava.multithreading;
//scenario 2=> second process of creating thread using runnable interface

   class MyClass1 implements Runnable
   {
	   public void run()
	   {
		   for(int i=1;i<=100;i++)
			   
		   {
			   System.out.println(i);
		   }
	   }
   }
public class MthreadingDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//the below two methods call show that threads r not under our control
		MyClass1 m1=new MyClass1();
		/*m1 is object reference and it is passed to thread t1 and we want thread class object*/
		Thread t1 = new Thread(m1);
		t1.start();
		
		Thread t2 = new Thread(m1);
		t2.start();	
	}
}
