package com.capg.corejava.multithreading;
//scenario 1=> first process of creating thread using thread class

   class MyClass extends Thread
   {
	   public void run()
	   {
		   for(int i=1;i<=100;i++)
			   
		   {
			   System.out.println(i);
		   }
	   }
   }
public class MthreadingDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//the below two methods call show that threads r not under our control
		MyClass t1=new MyClass();
		t1.start();
		
		MyClass t2=new MyClass();
		t2.start();
		
	}

}
