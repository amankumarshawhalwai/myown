package com.capg.corejava.collectionframework;
//scenario 3
//Iterator and hasNext() illustration
import java.util.ArrayList;
import java.util.Iterator;
public class ArrayListDemo3 {

	public static void main(String[] args) {
		
		ArrayList myList = new ArrayList();
		myList.add(100);
		myList.add("Ravi");
		myList.add(45.5);
		myList.add(90);
		myList.add(100);
		//System.out.println(myList);
		
		Iterator i1=myList.iterator();
		
		while(i1.hasNext())//hasNext() has return type boolean
		{
			System.out.println(i1.next());
		}//if hasNext() return true then the value is printed
		
		

	}

}
