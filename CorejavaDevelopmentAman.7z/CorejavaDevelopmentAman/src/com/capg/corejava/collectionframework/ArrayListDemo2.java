package com.capg.corejava.collectionframework;
//scenario2
import java.util.ArrayList;

public class ArrayListDemo2 {

	public static void main(String[] args) {
		
		ArrayList myList = new ArrayList();
		myList.add(100);
		myList.add("Ravi");
		myList.add(45.5);
		myList.add(90);
		myList.add(100);
		
		System.out.println(myList);
/* 
 *Output is like: [100, Ravi, 45.5, 90, 100]
 * A ArrayList stores the data in a order and also allows duplicate
 * elements in it
*/
	}

}
