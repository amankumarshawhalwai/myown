package com.capg.corejava.collectionframework;
import java.util.HashMap;
public class HashMapDemo9 {

	public static void main(String[] args) {
		HashMap<String,String> capitalCities = new HashMap<String,String>();
		capitalCities.put("India", "New Delhi");
		capitalCities.put("USA", "Washington dc");
		capitalCities.put("Brazil", "Brasilia");
		
		
		//System.out.println(capitalCities);
		//for(String i:capitalCities.values())//=>prints key values
	     for(String i:capitalCities.keySet())//prints keys
		{
			System.out.println(i);
		}
				}

}
