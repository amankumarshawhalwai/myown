package com.capg.corejava.collectionframework;
//scenario 1

import java.util.HashSet;
public class HashSetDemo1 {

	public static void main(String[] args) {
		HashSet mySet = new HashSet();
		mySet.add(100);
		mySet.add("Ravi");
		mySet.add(45.5);
		mySet.add(100);
		mySet.add(1);
		
		System.out.println(mySet);
	}
	/*Output is like [1, 100, Ravi, 45.5]
	 * this is because in HashSet data is stored randomly and 
	 * duplicates aren't allowed
	 */

}
