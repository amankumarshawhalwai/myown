package com.capg.corejava.collectionframework;
//Iterator on hashmap

import java.util.HashSet;
import java.util.Iterator;
public class HashSetDemo4 {

	public static void main(String[] args) {
		HashSet mySet = new HashSet();
		mySet.add(100);
		mySet.add("Ravi");
		mySet.add(45.5);
		mySet.add(100);
		mySet.add(1);
		
		//System.out.println(mySet);
        Iterator i1=mySet.iterator();
		
		while(i1.hasNext())//hasNext() has return type boolean
		{
			System.out.println(i1.next());
		}
	}
}
