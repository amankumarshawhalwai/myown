package com.capg.corejava.collectionframework;
import java.util.Hashtable;
public class HashtableDemo8 {

	public static void main(String[] args) {
		Hashtable myMap = new Hashtable();
		myMap.put(100,"Ramesh, 5500");
		myMap.put(90519, "379, 84days");
		myMap.put(93313, "48, 28days");
		myMap.put(100,"Ramesh, 5500");
		
		
		System.out.println(myMap);
				}

}
