package com.capg.corejava.collectionframework;
//Iterator on hashmap

import java.util.HashSet;
import java.util.Iterator;
public class HashSetDemo6 {

	public static void main(String[] args) {
		HashSet<String> mySet = new HashSet<String>();
		mySet.add("JAVA");
		mySet.add("Ravi");
		mySet.add("J2SE");
		mySet.add("J2EE");
		mySet.add("JAVA FRAMEWORK");
		
		
		//System.out.println(mySet);
        Iterator i1=mySet.iterator();
		
		while(i1.hasNext())//hasNext() has return type boolean
		{
			System.out.println(i1.next());
		}
		
		/*for(String s:mySet)//for each advanced loop its only requirement is
			//that it wants the same data type as the one on which it is operated
			System.out.println(s);*/
	}
}
