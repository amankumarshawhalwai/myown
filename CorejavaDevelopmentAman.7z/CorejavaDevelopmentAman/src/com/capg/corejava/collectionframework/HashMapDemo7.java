package com.capg.corejava.collectionframework;
import java.util.HashMap;
public class HashMapDemo7 {

	public static void main(String[] args) {
		HashMap myMap = new HashMap();
		myMap.put(100,"Ramesh, 5500");
		myMap.put(90519, "379, 84days");
		myMap.put(93313, "48, 28days");
		myMap.put(null,"null");
		myMap.put(8481,"null");
		myMap.put(null,"hello");
		System.out.println(myMap);
				}

}
