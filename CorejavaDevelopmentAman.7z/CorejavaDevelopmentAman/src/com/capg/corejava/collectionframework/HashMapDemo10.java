package com.capg.corejava.collectionframework;
import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapDemo10 {

	public static void main(String[] args) {
		HashMap<Integer,String> myMap = new HashMap<Integer,String>();
		myMap.put(100,"Ramesh");
		myMap.put(150, "Kiran");
		myMap.put(300,"Ram");
		
		
		
		//System.out.println(capitalCities);
		
		for(Entry<Integer, String> m:myMap.entrySet())
		{
			System.out.println("key :"+m.getKey()+" value :"+m.getValue());
		}
				}

}
