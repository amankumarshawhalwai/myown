package com.capg.corejava.collectionframework.comparator;

public class Student  {
	
	int sno;
	String sname;
	int age;
	 public Student(int sno, String sname,int age) {
			super();
			this.sno = sno;
			this.sname = sname;
			this.age=age;
			
		}
	
}
