package com.capg.corejava.collectionframework.comparator;

import java.util.ArrayList;
import java.util.Collections;

public class StudentImpl {

	public static void main(String[] args) {
	
      ArrayList<Student> stu= new ArrayList<Student>();
      
           stu.add(new Student(101,"Raju",23));
           stu.add(new Student(101,"Bhanu",27));
           stu.add(new Student(101,"Kiran",21));
           
           System.out.println("Sorting by Name");
           Collections.sort(stu,new SortByStudentName());
           
           for(Student s : stu) {
        	     System.out.println(s.sno +" "+s.sname +" "+s.age);
           }
           System.out.println("Sorting by Age");
           
           Collections.sort(stu,new SortByAge());
           
           for(Student st : stu) {
        	     System.out.println(st.sno +" "+st.sname +" "+st.age);
           }
	}
	
	
	
	
	

}
