package com.capg.corejava.interface1;

public interface NewBook {
	public void myNewBook();
	
}
