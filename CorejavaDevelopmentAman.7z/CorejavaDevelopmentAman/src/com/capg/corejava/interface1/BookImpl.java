package com.capg.corejava.interface1;
interface Book
{
	public void bookTitle();
	public void bookAuthor();
	public void bootPrice();
}
public class BookImpl implements Book {

	public void bookTitle()
	{
		System.out.println("Corejava Index");
	}
	public void bookAuthor()
	{
		System.out.println("Our class");
	}
	public void bootPrice()
	{
		System.out.println("Rs. 550");
	}
	public void show()
	{
		System.out.println("Local method of BookImpl");
	}
	public static void main(String[] args) {
		BookImpl book1 = new BookImpl();
		book1.bookTitle();
		book1.bookAuthor();
		book1.bootPrice();
		book1.show();

	}

}
