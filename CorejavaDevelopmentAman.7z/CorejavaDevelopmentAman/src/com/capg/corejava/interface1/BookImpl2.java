package com.capg.corejava.interface1;
interface Book2
{
	public void bookTitle();
	public void bookAuthor();
	public void bootPrice();
	String country="india";
}
public class BookImpl2 implements Book2 {

	public void bookTitle()//Interface method
	{
		System.out.println("Corejava Index"+country);
	}
	public void bookAuthor()//Interface method
	{
		System.out.println("Our class");
	}
	public void bootPrice()//Interface method
	{
		System.out.println("Rs. 550");
	}
	public void show()//local method
	{
		System.out.println("Local method of BookImpl");
	}
	public static void main(String[] args) {
		//the below object calls all the methods
		/*BookImpl2 book1 = new BookImpl2();
		book1.bookTitle();
		book1.bookAuthor();
		book1.bootPrice();
		book1.show();*/
		
		//Book2 b2= new Book2(); cannot instantiate the Book2

		Book2 b3 = new BookImpl2();//only want the interface methods and not the local methods
		b3.bookTitle();
		b3.bookAuthor();
		b3.bootPrice();
		
	}

}
