package com.capg.corejava.interface1;
interface Book3 //extends NewBook=>it can also be extended
{
	public void bookTitle();
	public void bookAuthor();
	public void bootPrice();
	String country="india";//variables 
}
//class can support multiple inheritance through interface
public class BookImpl3 implements Book3,NewBook 
{
	public void bookTitle()//Interface method
	{
		System.out.println("Corejava Index"+country);
	}
	public void bookAuthor()//Interface method
	{
		System.out.println("Our class");
	}
	public void bootPrice()//Interface method
	{
		System.out.println("Rs. 550");
	}
	public void myNewBook() 
	{
		System.out.println("My new book");
	}
	public void show()//local method
	{
		System.out.println("Local method of BookImpl");
	}
	public static void main(String[] args) {
		

		Book3 b3 = new BookImpl3();//only want the interface methods and not the local methods
		b3.bookTitle();
		b3.bookAuthor();
		b3.bootPrice();
		
	}

}
