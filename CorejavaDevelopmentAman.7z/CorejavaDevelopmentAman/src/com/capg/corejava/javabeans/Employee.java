package com.capg.corejava.javabeans;
import java.io.Serializable;
public class Employee implements Serializable{
//All members are private in javabeans
	private int eno;//0.0  100
	private String ename;//null ravi
	private double sal;//0.0 55000
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
	
	
	
}
