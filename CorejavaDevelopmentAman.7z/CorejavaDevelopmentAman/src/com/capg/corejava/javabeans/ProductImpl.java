package com.capg.corejava.javabeans;

public class ProductImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Product product = new Product(10,"Laptop",50000);
		
		System.out.println(product.getPno());
		System.out.println(product.getPname());
		System.out.println(product.getPrice());

	}

}
