package com.capg.corejava.javabeans;

public class EmployeeImpl {
	
	public static void main(String args[]) {
		//setting values to beans
		Employee emp = new Employee();
		emp.setEname("Ravi");
		emp.setEno(100);
		emp.setSal(55500);
		
		//retrieving values from beans
		System.out.println("Employee No:"+emp.getEno());
		System.out.println("Employee Name:"+emp.getEname());
		System.out.println("Employee Salary:"+emp.getSal());
	}

}
