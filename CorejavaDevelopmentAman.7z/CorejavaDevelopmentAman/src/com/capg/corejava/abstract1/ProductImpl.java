package com.capg.corejava.abstract1;

abstract class Product//abstract class
{
	public abstract void productInfo();//abstract method
	 
	public void showProduct()//implemented method
	{
		System.out.println("All products");
	}
}
public class ProductImpl extends Product{
/*If any class extends an abstract class then that should be overridden or the 
	class must be declared as abstract*/
	@Override
	public void productInfo() {
		System.out.println("Product info");
		
	}
	public static void main(String[] args) {
		ProductImpl product = new ProductImpl();
		product.showProduct();

	}

	

}
