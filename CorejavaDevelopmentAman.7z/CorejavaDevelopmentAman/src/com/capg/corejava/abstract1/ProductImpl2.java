package com.capg.corejava.abstract1;

abstract class Product2//abstract class
{
	public abstract void productInfo();//abstract method
	 
	public void showProduct()//implemented method
	{
		System.out.println("All products");
	}
}
public class ProductImpl2 extends Product2{

	public void productInfo() {
		System.out.println("Product info");
		
	}
	public static void main(String[] args) {
		//Product2 p1 = new Product2(); //cannot instantiate
		ProductImpl2 product = new ProductImpl2();
		//3 methods are..
		Product2 p2 = new ProductImpl2();
		
		p2.productInfo();
		p2.showProduct();

	}

	

}
