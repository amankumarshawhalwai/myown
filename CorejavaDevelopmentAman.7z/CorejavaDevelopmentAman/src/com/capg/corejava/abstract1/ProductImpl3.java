package com.capg.corejava.abstract1;

abstract class Product3//abstract class
{
	public abstract void productInfo();//abstract method
	
	Product3()//constructor
	{
		System.out.println("Abstract class constructors");
	}
	 
	public void showProduct()//implemented method
	{
		System.out.println("All products");
	}
}
public class ProductImpl3 extends Product3{

	public void productInfo() {
		System.out.println("Product info");
		
	}
	public void show()
	{
		System.out.println("Sub class methods");
	}
	public static void main(String[] args) {
		//Product2 p1 = new Product2(); //cannot instantiate
		ProductImpl3 product = new ProductImpl3();
		//3 methods are..
		Product3 p2 = new ProductImpl3();
		
		p2.productInfo();
		p2.showProduct();

	}

	

}
