package com.capg.corejava.wrapperClasses;

public class AutoBoxing_Unboxing{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int t1=100;
		Integer i1 = Integer.valueOf(t1);
		
		Integer k1=new Integer(10);
		int m=k1.intValue();//converting integer to int explicitly
		int d=k1;//Unboxing
		System.out.println(d);
	}

}
