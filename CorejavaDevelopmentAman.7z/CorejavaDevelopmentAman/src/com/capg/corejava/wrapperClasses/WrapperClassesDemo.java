package com.capg.corejava.wrapperClasses;

public class WrapperClassesDemo {

	public static void main(String[] args) {
		int t1=10;
		
		Integer i1=new Integer(t1);
		System.out.println(t1);

		Double d1 = new Double(45.5);
		
		double k1=d1.doubleValue();
		System.out.println(k1);
	}

}
