package com.capg.corejava.casting;

public class WideningDemo {

	public static void main(String[] args) {
		int t1=100;
		long l=t1;
		float f1=l;
		
		System.out.println("Before");
		System.out.println(t1);
		System.out.println("After conversion:"+l);
		System.out.println("After conversion:"+f1);
	}

}
