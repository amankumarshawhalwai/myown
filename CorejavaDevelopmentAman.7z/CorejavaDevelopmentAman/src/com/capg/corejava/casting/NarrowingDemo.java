package com.capg.corejava.casting;

public class NarrowingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double d1=45.65;
long l1 = (long)d1;
 System.out.println(l1);
 
 int t1=(int)l1;
 System.out.println(t1);
	}

}
