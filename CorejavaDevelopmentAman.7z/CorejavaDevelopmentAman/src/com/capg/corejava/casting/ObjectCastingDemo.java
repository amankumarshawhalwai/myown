package com.capg.corejava.casting;
class A
{
	public void show()
	{
		System.out.println("A class showA");
	}
}
class B extends A
{
	public void show()
	{
		System.out.println("B class showB");
	}
}
public class ObjectCastingDemo {

	public static void main(String[] args) {
		A a1 = new A();
		a1.show();
		
		B b1=new B();
		b1.show();
		
		a1=b1;
		a1.show();
		
		b1=(B)a1;
		b1.show();

	}

}
