package com.capg.corejava.objectclassmethods;

class Student
{
	int sno=10;
	String sname="Raju";
	public void show()
	{
		System.out.println("Student no="+sno);
		System.out.println("Student name="+sname);
	}
	public String toString() {
		return "Student No:" +sno+"Student Name:"+sname;
	}
}
public class ToStringDemo {

	public static void main(String[] args) {
		
		Student s1 = new Student();
		//s1.show();
		System.out.println(s1);
		System.out.println(s1.hashCode());
//hashcode() is used to return the location/address of the object which is a part of the object class method
//toString() is used get information about the object & when we want to use this method then we need to override it
		

	}

}
