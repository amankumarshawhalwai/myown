package com.capg.corejava.constructors;

public class Employee4 {
	int eno;//0 100 & these are instance variables
	String ename;//null Ramesh
	double sal;//0.0 55000
	Employee4()
	{
		System.out.println("Default constructor");
	}
	//if this is not used then 
	Employee4(int eno1,String ename1,double sal1)
	{
		this.eno=eno1;
		this.ename=ename1;
		this.sal=sal1;
	}
	public void display()
	{
		System.out.println("Employee no is:"+eno);
		System.out.println("Employee name is:"+ename);
		System.out.println("Employee saary is:"+sal);
	}
	public static void main(String[] args) {
		Employee4 emp=new Employee4();
		emp.display();
		Employee4 emp2=new Employee4(100,"Ramesh",55000);
		
		emp2.display();

	}

}
