package com.capg.corejava.constructors;

public class Employee2 {
	int eno;
	String ename;
	double sal;
	Employee2()
	{
		System.out.println("Default constructor");
	}
	Employee2(int eno1,String ename1,double sal1)
	{
		eno=eno1;
		ename=ename1;
		sal=sal1;
	}
	public void display()
	{
		System.out.println("Employee no is:"+eno);
		System.out.println("Employee name is:"+ename);
		System.out.println("Employee saary is:"+sal);
	}

	public static void main(String[] args) {
		Employee2 emp=new Employee2();
		emp.display();
		Employee2 emp2=new Employee2(100,"Ramesh",55);
		
		emp2.display();

	}

}
