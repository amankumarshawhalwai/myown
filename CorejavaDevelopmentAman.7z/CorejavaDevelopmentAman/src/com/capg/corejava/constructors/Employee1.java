package com.capg.corejava.constructors;

public class Employee1 {

	Employee1()
	{
		System.out.println("Default Constructor");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

