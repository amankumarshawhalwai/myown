package com.capg.corejava.constructors;

public class Person {
	String pname;
	int age;
	String address;
	
	Person()
	{
		System.out.println("Default constructor");
	}
	Person(int age,String pname,String address)
	{
		this.age=age;
		this.pname=pname;
		this.address=address;
	}
	public void display()
	{
		System.out.println("Person Age is:"+age);
		System.out.println("Person name is:"+pname);
		System.out.println("Person's address is:"+address);
	}

	public static void main(String[] args) {
		Person p=new Person();
		p.display();
		Person p2= new Person();
		p2.display();

	}

}
