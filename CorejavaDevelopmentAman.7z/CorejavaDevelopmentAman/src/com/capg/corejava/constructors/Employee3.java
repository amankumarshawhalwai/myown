package com.capg.corejava.constructors;

public class Employee3 {
	int eno;//0 100 & these are instance variables
	String ename;//null Ramesh
	double sal;//0.0 55000
	Employee3()
	{
		System.out.println("Default constructor");
	}
	//if this is not used then 
	Employee3(int eno1,String ename1,double sal1)//parameterized constructor
	{
		this.eno=eno1;
		this.ename=ename1;
		this.sal=sal1;
	}
	public void display()
	{
		System.out.println("Employee no is:"+eno);
		System.out.println("Employee name is:"+ename);
		System.out.println("Employee salary is:"+sal);
	}

	public static void main(String[] args) {
		Employee3 emp=new Employee3();
		emp.display();
		Employee3 emp2=new Employee3(100,"Ramesh",55000);
		
		emp2.display();

	}

}
