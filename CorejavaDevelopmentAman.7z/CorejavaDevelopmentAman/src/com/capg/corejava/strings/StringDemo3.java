package com.capg.corejava.strings;

public class StringDemo3 {

	public static void main(String[] args) {
		String str1 = new String("   CoreJava  ");
		
		System.out.println(str1.length());
		System.out.println(str1.toUpperCase());
		System.out.println(str1.toLowerCase());
		System.out.println((str1.trim()).length());
	}

}
