package com.capg.corejava.final1;
//illustrates that a FINAL METHOD CAN be USED from a FINAL CLASS by using a HAS-A relationship
final class Mytest1 //The type Mytest is already defined=>always change tha class name ina different program
{
	final public void show()
	{
		System.out.println("My test show");
		System.out.println("B.L ");
	}
}
//The type FinalDemo4 cannot subclass the final class Mytest1
public class FinalDemo4{
	public void show1() {//Cannot override the final method from Mytest 
		                //but if the name is changed to show1 then no issues are encountered
		System.out.println("Sub class");
	}
	public static void main(String[] args) {
		FinalDemo4 ovr=new FinalDemo4();
		
		Mytest1 my = new Mytest1();
		my.show();
	}

}
