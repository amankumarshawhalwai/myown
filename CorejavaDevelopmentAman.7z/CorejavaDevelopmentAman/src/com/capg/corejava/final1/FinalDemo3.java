package com.capg.corejava.final1;
//illustrates that a FINAL METHOD CANNOT be INHERITED
class Mytest
{
	final public void show()
	{
		System.out.println("My test show");
		System.out.println("B.L ");
	}
}
public class FinalDemo3 extends Mytest{
	public void show1() {//Cannot override the final method from Mytest 
		                //but if the name is changed to show1 then no issues are encountered
		System.out.println("Sub class");
	}
	public static void main(String[] args) {
		FinalDemo3 ovr=new FinalDemo3();
		ovr.show();
	}

}
