package com.capg.corejava.final1;
//illustrates that a FINAL METHOD CANNOT BE OVERRIDEN
public class FinalDemo2 {

	final String countryName="India";
	public void display()
	{
		//countryName="USA";//The final field FinalDemo1.countryName cannot be assigned
		System.out.println(countryName);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalDemo2 fd=new FinalDemo2();
		fd.display();

	}

}
