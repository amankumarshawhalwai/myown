package com.capg.corejava.static1;
//scenario_1
public class StaticDemo1 {
	static String countryName="India";
	
	public static void show()
	{
		System.out.println("Show methods");
	}

	public static void main(String[] args) {
		System.out.println(StaticDemo1.countryName);
		StaticDemo1.show();
	}

}
