package com.capg.corejava.static1;
//scenario_3
public class StaticDemo2 {
	static String countryName="India";
	       String name="Raju";
	
	static
	{
		System.out.println("Static blocks");
	}
	
	public static void show()
	{
		System.out.println("Show methods");
	}

	public static void main(String[] args) {
		System.out.println(StaticDemo2.countryName);
		StaticDemo2.show();
	}

}
