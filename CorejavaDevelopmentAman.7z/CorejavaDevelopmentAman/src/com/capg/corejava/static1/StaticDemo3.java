package com.capg.corejava.static1;
//scenario_3
public class StaticDemo3 {
	static String countryName="India";
	       String name="Raju";
	static
	{
		System.out.println("Static blocks");
	}
	
	public static void show()
	{
		countryName="USA";
		System.out.println("Show methods:"+countryName);
	}
	public void display()
	{
		name="Rakesh";
		System.out.println();
	}
	public static void main(String[] args) {
		System.out.println(StaticDemo3.countryName);
		StaticDemo3.show();
	}

}
