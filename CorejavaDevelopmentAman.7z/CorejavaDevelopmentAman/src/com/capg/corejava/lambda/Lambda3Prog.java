package com.capg.corejava.lambda;
//Lambda expressions=>No parameters
interface Person3
{
	public void eat();
}
public class Lambda3Prog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person3 p3 = () ->
				{
			//public void eat()
			{
				System.out.println("Eat");
				//this is the body
				System.out.println("Hello lambda exp");
			}
				};//lambda close
		p3.eat();
	}//main method close
}//class close
