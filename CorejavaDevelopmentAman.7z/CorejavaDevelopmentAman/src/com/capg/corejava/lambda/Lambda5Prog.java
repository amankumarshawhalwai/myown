package com.capg.corejava.lambda;
//Lambda expressions=>two parameters
interface Person5
{
	public void eat(String foodName1,String foodName2);
}
public class Lambda5Prog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person5 p5 = (foodName1,foodName2) ->
				{
			//public void eat()
			{
				System.out.println("bhai tui "+foodName1+" kha");
				System.out.println("bhai "+foodName2+" khabi?");
				//this is the body
				System.out.println("Hello lambda exp");
			}
				};//lambda close
		
p5.eat("jol","Mazza");
	}//main method close

}//class close
