package com.capg.corejava.lambda;

 interface Addition1
 {
	 public int addition(int a,int b);
 }
public class Lambda6AddProg {

	public static void main(String[] args) {
		
		Addition1  a1= (a,b) ->{
		{
			int sum=a+b;
			return sum;
		}

	};
	System.out.println("Sum is:" +a1.addition(2,5));
	
}
}
