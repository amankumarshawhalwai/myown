package com.capg.corejava.lambda;

interface Person2
{
	public void eat();
}
public class Lambda2Prog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person2 p2 = new Person2()
				{
			public void eat()
			{
				System.out.println("Eat");
			}
				};
		
p2.eat();
	}

}
