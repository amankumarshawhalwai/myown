package com.capg.corejava.lambda;

interface Person1
{
	public void eat();
}
public class Lambda1Prog implements Person1{

	
	@Override
	public void eat() {
		System.out.println("Eat");
	}
		
		public static void main(String[] args) {
	

	
		
	}

}
