package com.capg.corejava.lambda;
//Lambda expressions=> Single parameters
interface Person4
{
	public void eat(String foodName);
}
public class Lambda4Prog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person4 p4 = (foodName) ->
				{
			//public void eat()
			{
				System.out.println("bhai tui "+foodName+" kha");
				//this is the body
				System.out.println("Hello lambda exp");
			}
				};//lambda close
		
p4.eat("jol");
	}//main method close

}//class close
