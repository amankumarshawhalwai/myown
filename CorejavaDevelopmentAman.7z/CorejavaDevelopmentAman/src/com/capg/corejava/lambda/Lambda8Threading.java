package com.capg.corejava.lambda;

public class Lambda8Threading {

	public static void main(String[] args) {
		Runnable r1 = new Runnable() {

			@Override
			public void run() {
				System.out.println("Runnable Interface method with r1");
				
			}
		};
		Runnable r2=()->{
			System.out.println("Runnable Interface method with r2");
			
		};
		new Thread(r1).start();
		
		new Thread(r2).start();
	}

}
