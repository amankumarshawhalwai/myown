package com.capg.corejava.lambda;
//forEach loop version in a list with lambda expressions
import java.util.List;
import java.util.ArrayList;
public class Lambda7forEachLoop {

	public static void main(String[] args) {
		List<String> mygames = new ArrayList<String>();
		
		mygames.add("Chess");
		mygames.add("Hockey");
		mygames.add("Cricket");
		mygames.add("Kabaddi");
		
		/*for(String s:mygames)
			System.out.println(s);*/
		
		mygames.forEach(g->System.out.println(g));
	}

}
