package com.capg.corejava.exceptionhandling;
//scenario 4
public class ExceptionHandlingDemo3 {
String name="null";//if null then exception is return ed
int k=0,n=0;
	public void show()
	{ //open db connection or networking connections
		try {
			System.out.println(1);
			System.out.println(name.length());
			k=n/2;
			System.out.println(k);
			System.out.println(2);
			//close db connections
		}
		catch(NullPointerException ee)
		{
			System.out.println("I can handle exception"+ee);
		}
		catch(ArithmeticException ee)
		{
			System.out.println("I can handle exception"+ee);
		}
		catch(Exception ee)
		{
			System.out.println("I can handle exception"+ee);
		}
		finally
		{
			System.out.println("Finally block");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionHandlingDemo3 ex1 = new ExceptionHandlingDemo3();
		ex1.show();
	}

}
