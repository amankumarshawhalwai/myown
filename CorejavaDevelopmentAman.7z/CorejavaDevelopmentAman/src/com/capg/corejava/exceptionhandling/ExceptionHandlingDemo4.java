package com.capg.corejava.exceptionhandling;
//scenario 3
public class ExceptionHandlingDemo4 {
String name="null";//if null then exception is return ed
int k=0,n=0;
	public void show()
	{
		try {
			System.out.println(1);
			System.out.println(name.length());
			k=n/2;
			System.out.println(k);
			System.out.println(2);
		}
		/*catch(NullPointerException ee)
		{
			System.out.println("I can handle exception"+ee);
		}
		catch(ArithmeticException ee)
		{
			System.out.println("I can handle exception"+ee);
		}*/
		catch(Exception ee)
		{
			System.out.println("I can handle exception"+ee);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionHandlingDemo4 ex1 = new ExceptionHandlingDemo4();
		ex1.show();
	}

}
