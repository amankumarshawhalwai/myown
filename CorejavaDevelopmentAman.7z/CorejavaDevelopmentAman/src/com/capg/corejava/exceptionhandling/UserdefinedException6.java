package com.capg.corejava.exceptionhandling;
/*illustration of user defined exception using age such that 
if age>18 then only eligible for voting*/

class AgeNotSupportException extends Exception
{
	AgeNotSupportException(String message)//constructor
	{
		System.out.println("Your age is:"+message);
	}
}
public class UserdefinedException6 {

	int age=10;
	public void myData() throws Exception
	{
		if(age<=18)
		  /*throw*/	 new AgeNotSupportException("Not eligibe");
//if throws is used in the above line then that will reflect the exception
		else
			System.out.println("Eligible");
	}
	
	public static void main(String[] args) {
		try {
		UserdefinedException6 ude = new UserdefinedException6();
		ude.myData();
	}
		catch(Exception ee)
		{
			System.out.println("I can handle this:"+ee);
		}
}}
