package com.capg.corejava.exceptionhandling;
//scenario 1
public class ExceptionHandlingDemo1 {
String name=null;
	public void show()
	{
		System.out.println(name.length());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionHandlingDemo1 ex1 = new ExceptionHandlingDemo1();
		ex1.show();
	}

}
