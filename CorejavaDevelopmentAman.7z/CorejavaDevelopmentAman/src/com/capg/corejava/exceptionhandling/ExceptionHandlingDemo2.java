package com.capg.corejava.exceptionhandling;
//scenario 2
public class ExceptionHandlingDemo2 {
String name="null";//if null then exception is return ed
	public void show()
	{
		try {
			System.out.println(1);
			System.out.println(name.length());
			System.out.println(2);
		}
		catch(NullPointerException ee)
		{
			System.out.println("I can handle exception"+ee);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionHandlingDemo2 ex1 = new ExceptionHandlingDemo2();
		ex1.show();
	}

}
