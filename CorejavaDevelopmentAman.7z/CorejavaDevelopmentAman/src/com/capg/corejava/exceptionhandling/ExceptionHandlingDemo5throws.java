package com.capg.corejava.exceptionhandling;
//scenario 5
public class ExceptionHandlingDemo5throws {
String name="null";//if null then exception is return ed
int k=0,n=0;
	public void show() throws Exception
	//exception class is used since exception can handle all 
	//kinds of exceptions
	{
		
			System.out.println(1);
			System.out.println(name.length());
			k=n/2;
			System.out.println(k);
			System.out.println(2);
		}
		

	public static void main(String[] args) {
		try {
		ExceptionHandlingDemo5throws ex1 = new ExceptionHandlingDemo5throws();
		ex1.show();
	}
		catch(Exception ee)
		{
			System.out.println("I can handle exception"+ee);
		}

}}

