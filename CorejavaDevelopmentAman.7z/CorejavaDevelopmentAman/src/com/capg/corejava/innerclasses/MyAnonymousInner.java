package com.capg.corejava.innerclasses;

interface Person
{
	public void eat();
}
public class MyAnonymousInner {

	public static void main(String[] args) {
		
		Person p1 = new Person()
		{
			public void eat()
			{
				System.out.println("Rice");
			}
		};//close anonymous
		p1.eat();
	}

}
