package com.capg.corejava.innerclasses;

import java.util.Scanner;

interface hello
{
	public void show(int a,int b);
}
public class MyOuterClass {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter c:");int c=in.nextInt();
		System.out.println("Enter d:");int d=in.nextInt();
		
		hello p = (a,b) ->
				{
			
				System.out.println(a+b);
			
				};
				p.show(c,d);
	}

}
