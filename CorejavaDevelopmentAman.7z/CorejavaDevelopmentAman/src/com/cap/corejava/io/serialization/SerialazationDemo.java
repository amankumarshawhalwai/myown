package com.cap.corejava.io.serialization;
import java.io.FileOutputStream;
import java.io.*;
public class SerialazationDemo {

	public static void main(String[] args) {
		
		try {
			FileOutputStream fos = new FileOutputStream("product.txt");
			
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			ProductBean p1 = new ProductBean(100,"Mouse",450);
			ProductBean  p2 = new ProductBean(200,"Keyboard",350);
			ProductBean p3 = new ProductBean (300,"HDMI Cable",550);
			System.out.println("Writing objec into the stream");
			
			
	//oos points to fos and it points to product.txt
			//object serializable=>Converting object to byte Stream
			oos.writeObject(p1);
			oos.writeObject(p2);
			oos.writeObject(p3);
		}
		catch(Exception e)
		{
			System.out.println("End");
		}

	}

}
