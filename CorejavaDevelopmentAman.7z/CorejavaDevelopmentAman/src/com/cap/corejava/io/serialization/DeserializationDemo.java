package com.cap.corejava.io.serialization;
import java.io.*;
public class DeserializationDemo {

	public static void main(String[] args) {
		
		ProductBean p;
		try {
			FileInputStream fis = new FileInputStream("product.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			while((p=(ProductBean)ois.readObject())!=null)
				//(ProductBean) is object casting
			{
				System.out.println(p);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
